function isPrime(num) {
    if (num % 2 != 0 && num % 3 != 0 && num % 5 != 0 && num % 7 != 0) {
        return true;
    } else if (num == 2 || num == 3 || num == 5 || num == 7) {
        return true;
    } else {
        return false;
    }
}

function sumFirstNPrimeNumbers(amount) {
    let count = 0;
    let number = 2;
    let sum = 0;
    while (count < amount) {
        if (isPrime(number)) {
            count++;
            sum += number;
        }
        number++;
    }
    console.log(`Sum of first ${amount} prime numbers is ${sum}.`);
}

sumFirstNPrimeNumbers(1000);