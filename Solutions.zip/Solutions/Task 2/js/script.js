//Solution 1
let array = [2, 3, 6, 6, 8, 9, 10, 10, 10, 12, 12]

function removeDuplicates(array) {
    let newArray = [...new Set(array)];
    return newArray;
}
console.log(removeDuplicates(array));

//Solution 2
function removeDuplicates2(array) {
    let newArray = [];
    for (let i = 0; i < array.length; i++) {
        const element = array[i];
        if (newArray.indexOf(element) === -1) {
            newArray.push(element)
        }
    }
    return newArray;
}
console.log(removeDuplicates2(array));