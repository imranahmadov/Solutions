let test = "My e-mail : imranea@code.edu.az. My phone number is: +994774548884";
//let test = "Tiger Runs @ The Speed Of 100 km/hour."

function findPercentage(test) {
    let countUppercase = 0;
    let countLowercase = 0;
    let countDigits = 0;
    let countSymbols = 0;
    for (let i = 0; i < test.length; i++) {
        if (test[i].charCodeAt(0) >= 48 && test[i].charCodeAt(0) <= 57) {
            countDigits++;
        } else if (test[i].charCodeAt(0) >= 65 && test[i].charCodeAt(0) <= 90) {
            countUppercase++;
        } else if (test[i].charCodeAt(0) >= 97 && test[i].charCodeAt(0) <= 122) {
            countLowercase++;
        } else {
            countSymbols++;
        }
    }
    console.log(`Number of uppercase letters is ${countUppercase}. So percentage is ${(countUppercase*100/test.length).toFixed(2)}%`);
    console.log(`Number of lowercase letters is ${countLowercase}. So percentage is ${(countLowercase*100/test.length).toFixed(2)}%`);
    console.log(`Number of digits is ${countDigits}. So percentage is ${(countDigits*100/test.length).toFixed(2)}%`);
    console.log(`Number of other characters is ${countSymbols}. So percentage is ${(countSymbols*100/test.length).toFixed(2)}%`)
}
findPercentage(test)